Fontsmith Font Foundry Shareware Font Readme!

COPYRIGHT 
All fonts � 1999 The Fontsmith/
Crusades � 1999 The Fontsmith/

PERSONAL USE
This Font is Shareware and can be used free for 30 days 
after that We ask that you please pay a fee of $5.00.  
We are currently trying our best to build the finest fonts 
and web sight that we can, but we can't continue to do 
this without your support.  If you like our fonts and 
wish to see more, we would appreciate it very much if 
you would please pay the fee.  The more people that we
have pay will mean that we can release more freeware
fonts to you.

COMMERCIAL USE
Use of Crusades by commercial users 
(that is any form of business) or of any font made 
by Fontsmith must pay a $20.00 fee.

DISTRIBUTION
This font may be distributed for free by any means;
however, if you wish to make money by including this
in any kind of font distribution for sale, then 
please pay $5.00.  All distributed fonts including 
Crusades that are made by Fontsmith, must have all 
original files included in the distribution archive.  
NO FILES MAY BE ADDED TO THIS FILE ARCHIVE without 
prior permission.  A link to our web site must be 
included with your distribution, internet or otherwise.
http://www2.50megs.com/hephaestus

PAYMENTS
Please send shareware and any commercial fees to 
Scot Jenkins (Crusade's designer) at this address:
Scot Jenkins
1206 Shipwheel Ln
Gillette Wy,  82716

The Fontsmith 1999  
http://www2.50megs.com/hephaestus
iolaus@coffey.com
